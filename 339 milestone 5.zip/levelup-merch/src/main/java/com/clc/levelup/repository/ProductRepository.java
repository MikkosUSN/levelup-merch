package com.clc.levelup.repository;

import org.springframework.data.repository.CrudRepository;
import com.clc.levelup.model.Product;

public interface ProductRepository extends CrudRepository<Product, Long> {
    // We can add custom queries later if needed
}
